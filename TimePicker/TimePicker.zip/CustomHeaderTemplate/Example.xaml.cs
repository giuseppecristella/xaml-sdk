﻿using System.Windows.Controls;

namespace CustomHeaderTemplate
{
	/// <summary>
	/// Interaction logic for Example.xaml
	/// </summary>
	public partial class Example : UserControl
	{
		public Example()
		{
			InitializeComponent();
		}
	}
}
