﻿using System;

namespace AnnotationsSource
{
	public class RadTimelineDataItem
	{
		public DateTime StartDate { get; set; }

		public TimeSpan Duration { get; set; }
	}
}
