﻿using System.Windows;

namespace AnnotationsSource
{
	public partial class App : Application
	{
	}
}
