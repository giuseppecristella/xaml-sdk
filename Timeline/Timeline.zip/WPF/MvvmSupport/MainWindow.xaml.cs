﻿using System.Windows;

namespace MvvmSupport
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
