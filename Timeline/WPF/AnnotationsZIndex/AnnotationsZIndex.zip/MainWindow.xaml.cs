﻿using System.Windows;

namespace AnnotationsZIndex
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
