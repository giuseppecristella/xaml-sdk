﻿using System.Windows.Controls;

namespace Axis
{
	public partial class MainPage : UserControl
	{
		public MainPage()
		{
			InitializeComponent();
		}
	}
}
