﻿using System;
using System.Collections.ObjectModel;

namespace SeriesProvider
{
    public class SeriesProviderDataItem
    {
        public ObservableCollection<MyDataObject> Items { get; set; }
    }
}
