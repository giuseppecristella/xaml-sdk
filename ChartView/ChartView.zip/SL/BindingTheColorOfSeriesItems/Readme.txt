﻿This example will demonstrate how to create charts where each individual item has its color bound to a property of the underlying DataObject.
The following chart series will be used for this example:

  - Bar Series
  - Scatter Point Series
  - Pie Series