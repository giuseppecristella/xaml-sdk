﻿using System.Windows;

namespace ScatterSeries
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
