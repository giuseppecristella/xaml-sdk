﻿using System.Windows.Controls;

namespace AnnotationTypes
{
	public partial class RadialAxisPlotBandAnnotationDemo : UserControl
	{
		public RadialAxisPlotBandAnnotationDemo()
		{
			InitializeComponent();
		}
	}
}
