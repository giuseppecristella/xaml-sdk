﻿using System.Windows;

namespace RadTimeBarOverview
{
	public partial class App : Application
	{
	}
}
