﻿using System.Windows;
using Telerik.Windows.Controls;

namespace ScrollModes
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
