﻿using System.Windows;

namespace MvvmSupport
{
	public partial class App : Application
	{
	}
}
