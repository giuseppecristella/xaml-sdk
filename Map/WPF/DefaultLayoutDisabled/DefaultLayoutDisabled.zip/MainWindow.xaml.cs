﻿using System.Windows;

namespace DefaultLayoutDisabled
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
