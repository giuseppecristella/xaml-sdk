﻿using System.Windows;

namespace DistanceAndScaleExternalMapScale
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
