﻿using System.Windows;

namespace InformationLayerUnboundMode
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
