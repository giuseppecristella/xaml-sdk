﻿using System.Windows;

namespace InformationLayerMapShapeMapShapeFill
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
