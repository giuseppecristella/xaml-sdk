﻿using System.Windows;

namespace InformationLayerMapPath
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
