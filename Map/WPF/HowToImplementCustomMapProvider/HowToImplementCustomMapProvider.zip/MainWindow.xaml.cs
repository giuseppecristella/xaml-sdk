﻿using System.Windows;

namespace HowToImplementCustomMapProvider
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
