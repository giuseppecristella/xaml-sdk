﻿using System.Windows;

namespace InformationLayerColorizerModeStep
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
