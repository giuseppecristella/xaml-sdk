﻿using System.Windows;

namespace InformationLayerMapRectangle
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
