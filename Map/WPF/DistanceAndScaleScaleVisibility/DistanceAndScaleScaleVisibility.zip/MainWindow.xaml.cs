﻿using System.Windows;

namespace DistanceAndScaleScaleVisibility
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
