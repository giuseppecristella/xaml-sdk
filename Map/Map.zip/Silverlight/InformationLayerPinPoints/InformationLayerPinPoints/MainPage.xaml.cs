﻿using System.Windows.Controls;

namespace InformationLayerPinPoints
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
