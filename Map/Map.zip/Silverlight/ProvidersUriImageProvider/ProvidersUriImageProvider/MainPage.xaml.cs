﻿using System.Windows.Controls;

namespace ProvidersUriImageProvider
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
