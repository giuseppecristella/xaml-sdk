﻿using System.Windows.Controls;

namespace NavigationDisabled
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
