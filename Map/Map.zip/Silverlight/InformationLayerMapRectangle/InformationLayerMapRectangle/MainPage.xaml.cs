﻿using System.Windows.Controls;

namespace InformationLayerMapRectangle
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
