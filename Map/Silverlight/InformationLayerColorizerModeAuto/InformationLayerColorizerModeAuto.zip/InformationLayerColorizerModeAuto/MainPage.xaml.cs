﻿using System.Windows.Controls;

namespace InformationLayerColorizerModeAuto
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
