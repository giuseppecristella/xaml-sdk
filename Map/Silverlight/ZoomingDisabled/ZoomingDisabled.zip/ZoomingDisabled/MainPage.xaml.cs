﻿using System.Windows.Controls;

namespace ZoomingDisabled
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
