﻿using System.Windows.Controls;

namespace InformationLayerUnboundMode
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
