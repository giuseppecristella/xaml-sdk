﻿using System.Windows.Controls;

namespace CustomCellTemplates
{
	public partial class Example : UserControl
	{
		public Example()
		{
			InitializeComponent();
		}
	}
}
