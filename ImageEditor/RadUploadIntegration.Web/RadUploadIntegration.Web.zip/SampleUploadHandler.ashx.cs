﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Telerik.Windows;

namespace Example.Web
{
	/// <summary>
	/// Summary description for SampleUploadHandler
	/// </summary>
	public class SampleUploadHandler : RadUploadHandler
	{
	}
}