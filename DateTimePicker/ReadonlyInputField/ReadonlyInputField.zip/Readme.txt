This example demonstrates how to make the input field of the DateTimePicker/DatePicker controls read-only while the drop down calendar 
remains active for Silverlight and WPF.