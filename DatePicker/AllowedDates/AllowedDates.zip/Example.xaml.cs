﻿using System.Windows.Controls;

namespace AllowedDates
{
	public partial class Example : UserControl
	{
		public Example()
		{
			InitializeComponent();
		}
	}
}
