This example demonstrates how to use the SelectableDateStart, SelectableDateEnd and BlackoutDates in order 
to create a selectable range of dates for Silverlight and WPF. 

In the example only the current weekdays (Monday-Friday) are selectable.