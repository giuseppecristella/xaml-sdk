This example demonstrates how you can extend the stock ColumnFilterDescriptor in order to filter collection properties.
This example requires advanced knowledge of LINQ Expression Trees. 
You can learn more about LINQ Expression Trees at http://msdn.microsoft.com/en-us/library/bb397951.aspx