﻿namespace Colorizers
{
	public class GdpInfo
	{
		public string Continent { get; set; }
		public string Country { get; set; }
		public string City { get; set; }
		public double Gdp { get; set; }
	}
}
