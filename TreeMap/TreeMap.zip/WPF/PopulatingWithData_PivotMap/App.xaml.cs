﻿using System.Windows;

namespace PopulatingWithData_PivotMap
{
	public partial class App : Application
	{
	}
}
