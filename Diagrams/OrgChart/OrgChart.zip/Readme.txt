The Telerik OrgChart demo brings a great new visualization to organizational structures and hierarchies. 
DiagramOrgchart demonstrates the following RadDiagram  features:
   - Shapes Layout. Different Layout types. Customizing the Layout with properties
   - Connection Routing
   - Custom Connectors
   - Custom Templates changed with Semantic Zoom
   - BringIntoView functionality
   - Diagram NavigationPane
   - Search for a node
   - Animations when templates are changed
   