﻿using System;
using System.Linq;
using System.Windows.Controls;

namespace OrgChart
{
	public partial class MainPage : UserControl
	{
		public MainPage()
		{
			InitializeComponent();
		}
	}
}
