This sample demonstrates how to use any XAML control in a Diagram Shape.
You can put any content directly in a shape either in XAML or using C# code.