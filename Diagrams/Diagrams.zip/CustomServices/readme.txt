This example shows how you could customize some of the buld-in diagram services. 
The Diagramming Framework exposes a set of services that control and confugure different diagramming tools and features. 
This is why the services come in handy in scenarios requiring significant customizations in the default behavior of the RadDiagram and its elements