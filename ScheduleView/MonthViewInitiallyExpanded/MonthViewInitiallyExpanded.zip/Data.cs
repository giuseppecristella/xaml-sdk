﻿using System;
using System.Collections;

namespace MonthViewInitiallyExpanded
{
	public class Data
	{
		public IEnumerable Appointmentes { get; set; }
		public DateTime CurrentDate { get; set; }
	}
}
