﻿using System.Windows.Controls;

namespace MonthViewInitiallyExpanded
{
	public partial class MainPage : UserControl
	{
		public MainPage()
		{
			InitializeComponent();
		}
	}
}
