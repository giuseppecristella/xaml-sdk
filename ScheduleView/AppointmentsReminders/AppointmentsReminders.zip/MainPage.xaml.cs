﻿using System.Windows.Controls;

namespace AppointmentsReminders
{
    public partial class MainPage : UserControl
    {        
        public MainPage()
        {
            InitializeComponent();          
        }        
    }
}
