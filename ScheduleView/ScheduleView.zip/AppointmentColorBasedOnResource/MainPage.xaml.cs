﻿using System.Windows.Controls;

namespace AppointmentColorBasedOnResource
{
	public partial class MainPage : UserControl
	{
		public MainPage()
		{
			InitializeComponent();
		}
	}
}
