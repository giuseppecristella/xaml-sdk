This example demonstrates how to create a custom RadCalendar control and add a TodayButton in the controls Style that will select the current date 
in the control for Silverlight and WPF.