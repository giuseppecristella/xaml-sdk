﻿using System.Windows.Controls;

namespace WeekdaysButtonStyleSelector
{
	/// <summary>
	/// Interaction logic for Example.xaml
	/// </summary>
	public partial class Example : UserControl
	{
		public Example()
		{
			InitializeComponent();
		}
	}
}
