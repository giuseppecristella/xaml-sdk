﻿namespace MultipleYAxes
{
	public class ChartData
	{
		public int Value { get; set; }
	}
}
