﻿namespace CategoricalCharts
{
    public class FruitSales
    {
        public string Fruit { get; set; }
        public int Orders { get; set; }
    }
}
