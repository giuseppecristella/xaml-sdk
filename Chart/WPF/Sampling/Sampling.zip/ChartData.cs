﻿namespace Sampling
{
	public class ChartData
	{
		public double YVal { get; set; }
	}
}
