﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NegativeValues
{
	public class ChartData
	{
		public int XVal { get; set; }
		public int YVal { get; set; }
	}
}
