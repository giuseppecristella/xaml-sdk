﻿RadChart provides you with API, which you can use to build the charts you need from code-behind, without using XAML. This example will walk you through the common tasks of:

  - Adding RadChart and setting the DefaultView property in the code-behind
  - Adding ChartTitle in the code-behind
  - Adding ChartLegend in the code-behind
  - Adding ChartArea in the code-behind
  - Adding DataSeries in the code-behind