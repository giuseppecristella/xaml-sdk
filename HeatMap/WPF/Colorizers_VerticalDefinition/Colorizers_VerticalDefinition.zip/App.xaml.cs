﻿using System.Windows;

namespace Colorizers_VerticalDefinition
{
	public partial class App : Application
	{
	}
}
