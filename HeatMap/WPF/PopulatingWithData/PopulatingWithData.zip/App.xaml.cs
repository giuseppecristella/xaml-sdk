﻿using System.Windows;

namespace PopulatingWithData
{
	public partial class App : Application
	{
	}
}
