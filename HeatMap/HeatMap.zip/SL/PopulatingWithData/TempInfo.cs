﻿using System;

namespace PopulatingWithData
{
	public class TempInfo
	{
		public DateTime Year { get; set; }
		public string Month { get; set; }
		public double Temperature { get; set; }
		public double Rain { get; set; }
	}
}
