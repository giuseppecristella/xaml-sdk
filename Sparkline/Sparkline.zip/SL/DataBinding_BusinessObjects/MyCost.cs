﻿using System;

namespace DataBinding_BusinessObjects
{
	public class MyCost
	{
		public double Cost { get; set; }
		public double UnitCost { get; set; }
		public DateTime MyDate { get; set; }
	}
}
