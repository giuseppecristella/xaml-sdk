﻿using System.Windows.Controls;

namespace CloseSinglePaneInToolWindow
{
	public partial class Example : UserControl
	{
		public Example()
		{
			InitializeComponent();
		}
	}
}
