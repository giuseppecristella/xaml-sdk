This example demonstrates how to create a custom ItemsFactory and ToolWindow in order to 
customize the way the Close button of the floating ToolWindow closes Panes when there are multple Panes 
in the PaneGroup for Silverllight and WPF.

The example shows how to achieve a behavior, where the close button closes only the current 
active Pane rather then the hole PaneGroup.