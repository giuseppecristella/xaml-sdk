﻿using System.Windows;

namespace NumericScaleOverview
{
	public partial class App : Application
	{
	}
}
