﻿using System.Windows;

namespace HowToCreateThermometer
{
	public partial class App : Application
	{
	}
}
