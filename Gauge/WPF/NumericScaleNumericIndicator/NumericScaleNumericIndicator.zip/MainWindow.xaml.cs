﻿using System.Windows;

namespace NumericScaleNumericIndicator
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
