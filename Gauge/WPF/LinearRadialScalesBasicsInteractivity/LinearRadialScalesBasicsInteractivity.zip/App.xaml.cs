﻿using System.Windows;

namespace LinearRadialScalesBasicsInteractivity
{
	public partial class App : Application
	{
	}
}
