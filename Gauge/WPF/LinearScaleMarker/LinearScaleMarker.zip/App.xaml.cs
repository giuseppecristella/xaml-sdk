﻿using System.Windows;

namespace LinearScaleMarker
{
	public partial class App : Application
	{
	}
}
