﻿using System.Windows;

namespace LinearScaleTickMarksCustomTickMarks
{
	public partial class App : Application
	{
	}
}
