﻿using System.Windows;

namespace IndicatorsBasicsRefreshing
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
