﻿The TickProperties objects provide you with two ways of modifying the ticks' appearance:

  - Modifying Tick's Background
  - Specifying a DataTemplate