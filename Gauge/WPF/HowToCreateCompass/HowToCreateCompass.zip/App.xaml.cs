﻿using System.Windows;

namespace HowToCreateCompass
{
	public partial class App : Application
	{
	}
}
