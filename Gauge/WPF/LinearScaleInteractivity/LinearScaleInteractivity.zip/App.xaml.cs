﻿using System.Windows;

namespace LinearScaleInteractivity
{
	public partial class App : Application
	{
	}
}
