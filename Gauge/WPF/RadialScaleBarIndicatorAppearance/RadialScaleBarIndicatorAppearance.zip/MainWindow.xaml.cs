﻿using System.Windows;

namespace RadialScaleBarIndicatorAppearance
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
