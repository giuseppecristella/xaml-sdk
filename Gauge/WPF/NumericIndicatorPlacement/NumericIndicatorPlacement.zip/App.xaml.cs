﻿using System.Windows;

namespace NumericIndicatorPlacement
{
	public partial class App : Application
	{
	}
}
