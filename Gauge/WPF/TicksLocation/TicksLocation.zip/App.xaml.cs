﻿using System.Windows;

namespace TicksLocation
{
	public partial class App : Application
	{
	}
}
