﻿using System.Windows;

namespace DataBinding
{
	public partial class App : Application
	{
	}
}
