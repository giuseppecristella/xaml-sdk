﻿using System.Windows;

namespace LinearRadialScalesBasicsScaleOffsets
{
	public partial class App : Application
	{
	}
}
