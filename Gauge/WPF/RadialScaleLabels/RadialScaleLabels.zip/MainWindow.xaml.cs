﻿using System.Windows;

namespace RadialScaleLabels
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
