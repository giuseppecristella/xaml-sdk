﻿using System.Windows;

namespace RadialScaleStateIndicator
{
	public partial class App : Application
	{
	}
}
