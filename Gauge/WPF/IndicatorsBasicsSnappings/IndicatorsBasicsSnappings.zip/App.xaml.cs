﻿using System.Windows;

namespace IndicatorsBasicsSnapping
{
	public partial class App : Application
	{
	}
}
