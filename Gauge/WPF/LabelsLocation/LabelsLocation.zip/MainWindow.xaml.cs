﻿using System.Windows;

namespace LabelsLocation
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
