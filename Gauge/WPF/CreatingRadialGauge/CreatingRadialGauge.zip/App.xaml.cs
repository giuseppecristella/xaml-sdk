﻿using System.Windows;

namespace CreatingRadialGauge
{
	public partial class App : Application
	{
	}
}
