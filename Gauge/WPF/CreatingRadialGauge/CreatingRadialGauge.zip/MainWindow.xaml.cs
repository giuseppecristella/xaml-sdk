﻿using System.Windows;

namespace CreatingRadialGauge
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
