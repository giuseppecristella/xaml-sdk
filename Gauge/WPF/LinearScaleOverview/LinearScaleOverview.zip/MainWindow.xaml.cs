﻿using System.Windows;

namespace LinearScaleOverview
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
