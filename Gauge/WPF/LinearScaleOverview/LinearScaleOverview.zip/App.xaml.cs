﻿using System.Windows;

namespace LinearScaleOverview
{
	public partial class App : Application
	{
	}
}
