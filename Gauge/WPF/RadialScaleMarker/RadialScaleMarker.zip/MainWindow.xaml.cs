﻿using System.Windows;

namespace RadialScaleMarker
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
