﻿using System.Windows;

namespace LinearRadialScalesLinearScalePlacement
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
