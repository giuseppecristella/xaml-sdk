﻿using System.Windows;

namespace GaugeRangeMaxAndMinValue
{
	public partial class App : Application
	{
	}
}
