﻿using System.Windows;

namespace LinearRadialScalesBasicsScaleWidth
{
	public partial class App : Application
	{
	}
}
