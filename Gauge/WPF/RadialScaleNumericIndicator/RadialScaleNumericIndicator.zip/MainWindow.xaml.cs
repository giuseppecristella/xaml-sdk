﻿using System.Windows;

namespace RadialScaleNumericIndicator
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
