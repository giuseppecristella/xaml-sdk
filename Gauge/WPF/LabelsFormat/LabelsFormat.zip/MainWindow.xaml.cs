﻿using System.Windows;

namespace LabelsFormat
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
