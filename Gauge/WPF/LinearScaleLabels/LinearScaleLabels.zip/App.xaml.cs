﻿using System.Windows;

namespace LinearScaleLabels
{
	public partial class App : Application
	{
	}
}
