﻿using System.Windows;

namespace LinearScaleLabels
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
