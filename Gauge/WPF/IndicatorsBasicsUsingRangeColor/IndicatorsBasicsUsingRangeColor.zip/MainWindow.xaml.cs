﻿using System.Windows;

namespace IndicatorsBasicsUsingRangeColor
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
