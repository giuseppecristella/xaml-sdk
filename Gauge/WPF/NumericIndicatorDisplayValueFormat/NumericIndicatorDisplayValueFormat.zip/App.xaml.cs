﻿using System.Windows;

namespace NumericIndicatorDisplayValueFormat
{
	public partial class App : Application
	{
	}
}
