﻿using System.Windows;

namespace NumericIndicatorNumberPositions
{
	public partial class App : Application
	{
	}
}
