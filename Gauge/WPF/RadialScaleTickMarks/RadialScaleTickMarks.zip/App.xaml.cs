﻿using System.Windows;

namespace RadialScaleTickMarks
{
	public partial class App : Application
	{
	}
}
