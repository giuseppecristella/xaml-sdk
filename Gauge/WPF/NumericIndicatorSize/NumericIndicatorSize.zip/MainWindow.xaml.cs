﻿using System.Windows;

namespace NumericIndicatorSize
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
