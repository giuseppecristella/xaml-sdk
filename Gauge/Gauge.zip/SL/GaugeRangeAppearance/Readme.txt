﻿To control the appearance of a range you can use the following properties:

  - Background - specifies the fill color for the range.
  - Stroke - specifies the stroke color for the range.
  - StrokeThickness - specifies the thickness of the range's stroke.