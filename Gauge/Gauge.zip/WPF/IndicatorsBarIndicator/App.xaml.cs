﻿using System.Windows;

namespace IndicatorsBarIndicator
{
	public partial class App : Application
	{
	}
}
