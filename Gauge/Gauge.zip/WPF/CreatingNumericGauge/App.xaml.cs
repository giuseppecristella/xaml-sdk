﻿using System.Windows;

namespace CreatingNumericGauge
{
	public partial class App : Application
	{
	}
}
