﻿using System.Windows;

namespace CreatingNumericGauge
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
