﻿using System.Windows;

namespace GaugeRangeLabelsAppearance
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
