﻿using System.Windows;

namespace IndicatorsBasicsSize
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
