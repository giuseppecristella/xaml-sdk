﻿using System.Windows;

namespace IndicatorsBasicsSize
{
	public partial class App : Application
	{
	}
}
