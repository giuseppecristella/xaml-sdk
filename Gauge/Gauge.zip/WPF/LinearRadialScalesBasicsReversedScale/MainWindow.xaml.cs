﻿using System.Windows;

namespace LinearRadialScalesBasicsReversedScale
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
