﻿using System.Windows;

namespace IndicatorsStateIndicator
{
	public partial class App : Application
	{
	}
}
