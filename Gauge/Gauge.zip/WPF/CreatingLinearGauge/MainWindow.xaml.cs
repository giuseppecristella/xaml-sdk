﻿using System.Windows;

namespace CreatingLinearGauge
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
