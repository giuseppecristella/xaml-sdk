﻿using System.Windows;

namespace IndicatorsMarker
{
	public partial class App : Application
	{
	}
}
