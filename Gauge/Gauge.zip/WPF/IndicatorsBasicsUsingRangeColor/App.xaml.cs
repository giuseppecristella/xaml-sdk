﻿using System.Windows;

namespace IndicatorsBasicsUsingRangeColor
{
	public partial class App : Application
	{
	}
}
