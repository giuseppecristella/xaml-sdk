﻿using System.Windows;

namespace GaugeRangeIndicatorBackground
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
