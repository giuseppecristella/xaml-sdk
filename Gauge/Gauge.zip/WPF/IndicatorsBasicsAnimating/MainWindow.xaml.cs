﻿using System.Windows;

namespace IndicatorsBasicsAnimating
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
